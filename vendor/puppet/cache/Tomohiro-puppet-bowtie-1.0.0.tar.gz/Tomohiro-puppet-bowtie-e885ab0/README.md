Bowtie Puppet Module for Boxen
================================================================================

Install [Bowtie](http://bowtieapp.com/)


Usage
--------------------------------------------------------------------------------

```puppet
include bowtie
```
