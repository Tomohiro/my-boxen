# Postgres.app Puppet Module for Boxen

Install [Postgres.app](http://postgresapp.com/) via Boxen.

## Usage

```puppet
include postgresapp
```

## Required Puppet Modules

* `boxen`
