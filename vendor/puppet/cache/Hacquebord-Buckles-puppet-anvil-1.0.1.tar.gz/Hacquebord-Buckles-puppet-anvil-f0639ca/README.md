# Anvil Puppet Module for Boxen

This Puppet module install [Anvil](http://anvilformac.com). It's GUI for [Pow, a zero-config Rack server for Mac OS X](http://pow.cx).

A great module has a working travis build

[![Build Status](https://travis-ci.org/Hacquebord-Buckles/puppet-anvil.png?branch=master)](https://travis-ci.org/Hacquebord-Buckles/puppet-anvil)

## Usage

```puppet
include anvil
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
