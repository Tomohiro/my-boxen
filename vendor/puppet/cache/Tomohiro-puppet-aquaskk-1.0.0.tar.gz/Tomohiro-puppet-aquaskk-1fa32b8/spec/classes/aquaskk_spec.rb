require 'spec_helper'

describe 'aquaskk' do
  it { should include_class('aquaskk') }
  it { should contain_package('aquaskk') }
end
