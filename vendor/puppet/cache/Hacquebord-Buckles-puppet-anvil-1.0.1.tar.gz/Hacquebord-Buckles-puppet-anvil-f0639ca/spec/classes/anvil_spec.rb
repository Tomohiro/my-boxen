require 'spec_helper'
# Rename this file to classname_spec.rb
# Check other boxen modules for examples
# or read http://rspec-puppet.com/tutorial/
describe 'anvil' do
  it do
    should contain_package('Anvil').with({
      :provider => 'compressed_app',
      :source   => 'http://s3.amazonaws.com/sparkler_versions/versions/uploads/000/000/033/original/Anvil.zip',
    })
  end
end
